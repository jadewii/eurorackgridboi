// Universal Navigation for all EUROGRID pages
document.addEventListener('DOMContentLoaded', function() {
    // Create the universal navigation HTML
    const navHTML = `
    <style>
        .universal-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: white;
            border-bottom: 2px solid #000;
            padding: 15px 20px;
            z-index: 10000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-family: 'Noto Sans Mono', monospace;
        }
        
        .universal-logo {
            font-size: 1.5rem;
            font-weight: bold;
            letter-spacing: 3px;
            cursor: pointer;
            color: #000;
        }
        
        .universal-nav {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .universal-nav-btn {
            background: white;
            color: #000;
            border: 2px solid #000;
            padding: 8px 15px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s;
            text-transform: uppercase;
            font-size: 0.9rem;
            text-decoration: none;
            display: inline-block;
        }
        
        .universal-nav-btn:hover {
            background: #000;
            color: white;
        }
        
        .universal-nav-btn.active {
            background: #000;
            color: white;
        }
        
        .universal-profile-wrapper {
            position: relative;
            width: 60px;
            height: 60px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-left: 10px;
        }
        
        .universal-profile-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            border: 2px solid #000;
            z-index: 2;
            position: relative;
        }
        
        .universal-jacknut-ring {
            position: absolute;
            width: 60px;
            height: 60px;
            top: 0;
            left: 0;
            z-index: 3;
            pointer-events: none;
        }
        
        body {
            padding-top: 70px !important;
        }
    </style>
    
    <div class="universal-header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <div class="universal-logo" onclick="window.location.href='index.html'">EURORACKGRID</div>
            <div class="universal-profile-wrapper" onclick="window.location.href='my-studio.html'">
                <div class="universal-profile-avatar">${window.userSystem && window.userSystem.currentUser ? window.userSystem.currentUser.email.charAt(0).toUpperCase() : 'J'}</div>
                <img src="https://jqxshcyqxhbmvqrrthxy.supabase.co/storage/v1/object/public/icons/jacknut.png" class="universal-jacknut-ring" alt="">
            </div>
        </div>
        <div class="universal-nav">
            <a href="landing.html" class="universal-nav-btn ${window.location.pathname.includes('landing.html') ? 'active' : ''}">HOME</a>
            <a href="my-studio.html" class="universal-nav-btn ${window.location.pathname.includes('my-studio.html') || window.location.pathname.includes('index.html') ? 'active' : ''}">MY STUDIO</a>
            <a href="my-gear.html" class="universal-nav-btn ${window.location.pathname.includes('my-gear.html') ? 'active' : ''}">MY GEAR</a>
            <a href="my-modules.html" class="universal-nav-btn ${window.location.pathname.includes('my-modules.html') ? 'active' : ''}">MY MODULES</a>
            <a href="collection.html" class="universal-nav-btn ${window.location.pathname.includes('collection.html') ? 'active' : ''}">MODULES</a>
            <a href="rack-shop.html" class="universal-nav-btn ${window.location.pathname.includes('rack-shop.html') ? 'active' : ''}">RACKS</a>
            <a href="module-packs.html" class="universal-nav-btn ${window.location.pathname.includes('module-packs.html') ? 'active' : ''}">PACKS</a>
            <a href="panels.html" class="universal-nav-btn ${window.location.pathname.includes('panels.html') ? 'active' : ''}">PANELS</a>
            <a href="starters.html" class="universal-nav-btn ${window.location.pathname.includes('starters.html') || window.location.pathname.includes('starter-kits.html') ? 'active' : ''}">STARTER KITS</a>
            <a href="prebuilt-cases.html" class="universal-nav-btn ${window.location.pathname.includes('prebuilt-cases.html') ? 'active' : ''}">SYSTEMS</a>
            <a href="vibe-shop.html" class="universal-nav-btn ${window.location.pathname.includes('vibe-shop.html') ? 'active' : ''}">VIBE SHOP</a>
            <a href="buy-jamnutz.html" class="universal-nav-btn ${window.location.pathname.includes('buy-jamnutz.html') ? 'active' : ''}" style="background: #00FF00; color: #000; border-color: #000;">BUY 🥜</a>
        </div>
    </div>
    `;
    
    // Remove any existing header
    const existingHeaders = document.querySelectorAll('.header-bar, .universal-header');
    existingHeaders.forEach(header => header.remove());
    
    // Insert the new universal navigation at the beginning of body
    document.body.insertAdjacentHTML('afterbegin', navHTML);
    
    // Adjust main content padding if needed
    const mainContent = document.querySelector('.main-content');
    if (mainContent && !mainContent.style.paddingTop) {
        mainContent.style.paddingTop = '100px';
    }
    
    // Add jamnutz counter if user is logged in
    if (window.userSystem && window.userSystem.currentUser) {
        const jamnutzDisplay = document.createElement('div');
        jamnutzDisplay.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            background: #FFD700;
            color: #000;
            padding: 8px 15px;
            border-radius: 20px;
            border: 2px solid #000;
            font-weight: bold;
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 5px;
            font-family: 'Noto Sans Mono', monospace;
        `;
        jamnutzDisplay.innerHTML = `
            ${window.userSystem.currentUser.jamnutz}
            <img src="https://jqxshcyqxhbmvqrrthxy.supabase.co/storage/v1/object/public/icons/jacknut.png" style="width: 20px; height: 20px;">
        `;
        document.body.appendChild(jamnutzDisplay);
    }
});